# Power BI data model

Use a star schema with single-direction filters from each dimension to the fact tables.

## Relationships

| From (one) | To (many) | Cardinality | Cross-filter |
| --- | --- | --- | --- |
| `DimDate[Date]` | `FactSales[OrderDate]` | One-to-many | Single |
| `DimDate[Date]` | `FactTargets[MonthStart]` | One-to-many | Single |
| `DimProduct[ProductKey]` | `FactSales[ProductKey]` | One-to-many | Single |
| `DimCustomer[CustomerKey]` | `FactSales[CustomerKey]` | One-to-many | Single |
| `DimRegion[RegionKey]` | `FactSales[RegionKey]` | One-to-many | Single |
| `DimRegion[RegionKey]` | `FactTargets[RegionKey]` | One-to-many | Single |
| `DimSalesperson[SalespersonKey]` | `FactSales[SalespersonKey]` | One-to-many | Single |

## Model setup

1. Mark `DimDate[Date]` as the date table.
2. Sort `DimDate[MonthName]` by `DimDate[MonthNumber]`.
3. Sort `DimDate[YearMonth]` by `DimDate[MonthStart]`.
4. Keep all relationships active and single-direction.
5. Do not relate `DimRegion` directly to `DimCustomer` or `DimSalesperson`; those tables already filter sales through `FactSales`.
6. Hide technical keys, raw cost columns, and the `FactSales[ProfitMargin]` column from report view. Use measures for displayed KPIs.
7. Set monetary columns and measures to BDT currency and percentage measures to one decimal place.

## Recommended display folders

- **Sales:** Total Sales, Gross Sales, Total Discount, Units Sold, Average Order Value
- **Profit:** Total Profit, Total Cost, Profit Margin %, Profit YTD
- **Orders & Customers:** Completed Orders, Active Customers, Returned Orders, Return Rate %
- **Targets:** Sales Target, Sales Variance to Target, Target Achievement %, Profit Target Achievement %
- **Time Intelligence:** Sales Last Year, Sales YoY %, Sales YTD, Profit Last Year, Profit YoY %
- **Ranking:** Product Sales Rank, Top Product

