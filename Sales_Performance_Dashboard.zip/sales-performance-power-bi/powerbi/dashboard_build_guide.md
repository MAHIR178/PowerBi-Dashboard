# Dashboard build guide

## Page setup

- Page name: `Executive Overview`
- Canvas: 16:9 widescreen
- Background: `#F4F7FB`
- Header: `#17223B`
- Primary accent: `#0F766E`
- Use the supplied theme before formatting individual visuals.

## Header slicers

Add four dropdown slicers in the top-right header area:

1. `DimDate[Year]`
2. `DimRegion[Region]`
3. `DimProduct[Category]`
4. `FactSales[Channel]`

Enable search for Region and Category. Use a consistent dark header fill and white text.

## KPI row

Create four card visuals:

| Card | Main measure | Supporting context |
| --- | --- | --- |
| Total Sales | `[Total Sales]` | `[Sales YoY %]` |
| Total Profit | `[Total Profit]` | `[Profit Margin %]` |
| Completed Orders | `[Completed Orders]` | `[Average Order Value]` |
| Target Achievement | `[Target Achievement %]` | `[Sales Variance to Target]` |

Use conditional colors: green above target, amber at 90–99.9%, and red below 90%.

## Main visuals

### 1. Monthly sales and profit trend

- Visual: Line chart
- X-axis: `DimDate[YearMonth]`
- Y-axis: `[Total Sales]`, `[Total Profit]`
- Sort: `DimDate[MonthStart]`, ascending
- Colors: Sales `#0F766E`; Profit `#F59E0B`
- Tooltip: Sales, Profit, Profit Margin %, Sales YoY %

### 2. Sales by region

- Visual: Clustered bar or column chart
- Axis: `DimRegion[Region]`
- Value: `[Total Sales]`
- Sort: Total Sales, descending
- Turn on data labels and show values in millions

### 3. Sales mix by category

- Visual: Doughnut chart
- Legend: `DimProduct[Category]`
- Value: `[Total Sales]`
- Show category, percentage of total, and legend

### 4. Top 5 products

- Visual: Horizontal bar chart
- Y-axis: `DimProduct[ProductName]`
- X-axis: `[Total Sales]`
- Visual filter: Top N = 5 by `[Total Sales]`
- Sort: Total Sales, descending

### 5. Salesperson performance

- Visual: Matrix or table
- Rows: `DimSalesperson[SalespersonName]`
- Values: `[Total Sales]`, `[Total Profit]`, `[Profit Margin %]`, `[Target Achievement %]`
- Conditional formatting: Data bars for Total Sales; traffic-light icons for Target Achievement

## Interactions and usability

- Make all slicers filter every chart and card.
- Let Region and Category charts cross-filter the other visuals.
- Keep titles short and use explicit units such as `BDT millions`.
- Use one decimal place for percentages and no decimals for currency cards.
- Add a Reset Filters bookmark and button.
- Add a tooltip page with Sales, Profit, Margin, Orders, and YoY % for the hovered category.

## Final checks

- Confirm `Total Sales` is approximately BDT 134.8M with no filters.
- Confirm `Total Profit` is approximately BDT 36.4M.
- Confirm completed orders equal 2,035.
- Confirm target achievement is approximately 102.2%.
- Verify that returned and cancelled orders are excluded from sales and profit measures.
- Save the final report as `Sales_Performance_Dashboard.pbix` or as a source-control-friendly `.pbip` project.

