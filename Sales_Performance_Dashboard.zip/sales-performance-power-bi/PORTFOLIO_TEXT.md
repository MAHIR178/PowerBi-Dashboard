# Portfolio text

## GitHub repository description

Interactive Power BI sales dashboard with a star-schema model, DAX time intelligence, regional and product analysis, target tracking, Excel source data, and SQL queries.

## CV project entry

**Sales Performance Dashboard | Power BI, DAX, Excel, SQL**  
Built an interactive retail sales dashboard using a seven-table star schema and 4,101 transaction lines. Developed DAX measures for sales, profit, margin, YoY growth, returns, and target achievement; created interactive filters and business-focused visualizations for regional, product, customer, and salesperson performance.

## Short interview explanation

I created a Power BI dashboard to help retail managers monitor sales and profitability. I structured the data as a star schema, created DAX measures for key KPIs and time intelligence, and designed interactive views for trends, regions, categories, products, salespeople, and targets. The main insights were 29.9% sales growth in 2025, 102.2% target achievement, and strong concentration in the Central region and laptop category.

## Suggested GitHub topics

`power-bi` `dax` `data-analytics` `business-intelligence` `dashboard` `sql` `excel` `data-visualization` `portfolio-project`

