# Sales Performance Dashboard — Power BI

An end-to-end Power BI portfolio project for analyzing retail sales, profit, targets, products, regions, customers, and salesperson performance in Bangladesh.

![Sales Performance Dashboard preview](assets/dashboard_preview.png)

## Project overview

This project uses a synthetic 2024–2025 retail dataset and a star-schema data model. It is designed to demonstrate practical Power BI skills: data preparation, relationship modeling, DAX, KPI design, time intelligence, target tracking, slicers, and business storytelling.

| KPI | Portfolio result |
| --- | ---: |
| Completed sales | BDT 134.8M |
| Completed profit | BDT 36.4M |
| Profit margin | 27.0% |
| Completed orders | 2,035 |
| Average order value | BDT 66,216 |
| Sales target achievement | 102.2% |
| Return rate | 4.8% |
| 2025 sales growth vs 2024 | 29.9% |

## Dashboard features

- Interactive slicers for Year, Region, Category, and Channel
- KPI cards for Sales, Profit, Orders, and Target Achievement
- Monthly sales and profit trend with year-over-year measures
- Regional sales ranking
- Category contribution and Top 5 products
- Customer, salesperson, and target-performance analysis
- Consistent custom theme and BDT currency formatting

## Data model

The report uses seven tables with single-direction, one-to-many relationships.

| One side | Many side | Key |
| --- | --- | --- |
| `DimDate` | `FactSales` | `Date` → `OrderDate` |
| `DimDate` | `FactTargets` | `Date` → `MonthStart` |
| `DimProduct` | `FactSales` | `ProductKey` |
| `DimCustomer` | `FactSales` | `CustomerKey` |
| `DimRegion` | `FactSales` | `RegionKey` |
| `DimRegion` | `FactTargets` | `RegionKey` |
| `DimSalesperson` | `FactSales` | `SalespersonKey` |

## Repository structure

```text
sales-performance-power-bi/
├── assets/
│   ├── dashboard_preview.png
│   └── excel_dashboard_guide.png
├── data/
│   ├── Sales_Performance_Data.xlsx
│   ├── fact_sales.csv
│   ├── fact_targets.csv
│   ├── dim_customer.csv
│   ├── dim_date.csv
│   ├── dim_product.csv
│   ├── dim_region.csv
│   └── dim_salesperson.csv
├── powerbi/
│   ├── Sales_Performance_Theme.json
│   ├── dashboard_build_guide.md
│   ├── data_model.md
│   └── measures.dax
├── sql/
│   └── analysis_queries.sql
├── PORTFOLIO_TEXT.md
└── README.md
```

## Build the report in Power BI Desktop

1. Download or clone this repository.
2. In Power BI Desktop, select **Get data → Excel workbook** and open `data/Sales_Performance_Data.xlsx`.
3. Select the seven model tables: `FactSalesTable`, `FactTargetsTable`, `DimDateTable`, `DimProductTable`, `DimCustomerTable`, `DimRegionTable`, and `DimSalespersonTable`.
4. Rename them without the `Table` suffix and create the relationships in [`powerbi/data_model.md`](powerbi/data_model.md).
5. Mark `DimDate[Date]` as the date table.
6. Add the measures from [`powerbi/measures.dax`](powerbi/measures.dax).
7. Import [`powerbi/Sales_Performance_Theme.json`](powerbi/Sales_Performance_Theme.json) from **View → Themes → Browse for themes**.
8. Follow [`powerbi/dashboard_build_guide.md`](powerbi/dashboard_build_guide.md) to create the visuals and slicer interactions.
9. Save the completed report as `Sales_Performance_Dashboard.pbix`. For source-control-friendly text files, Power BI Desktop can also save a project as `.pbip`.

## Business insights

- Sales increased by **29.9% in 2025** compared with 2024.
- The **Central region** generated BDT 48.2M, or **35.8%** of completed sales.
- **NovaBook Pro Laptop** was the top-selling product at BDT 27.0M.
- **Nusrat Jahan** led salesperson performance with BDT 24.8M in sales.
- Overall sales reached **102.2% of target**, while the return rate remained **4.8%**.

## Skills demonstrated

Power BI, DAX, Power Query, data modeling, time intelligence, KPI design, dashboard design, Microsoft Excel, SQL, and business analysis.

## Data note

The dataset is synthetic and was created solely for portfolio demonstration. It contains no real customer, employee, or company information.

## Power BI references

- [Power BI Desktop projects](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview)
- [Use report themes in Power BI](https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-report-themes)

