/*
  Optional SQL Server analysis queries for the Sales Performance Dashboard.
  Assumes the CSV tables have been loaded as dbo.FactSales, dbo.FactTargets,
  dbo.DimProduct, dbo.DimRegion, dbo.DimSalesperson, dbo.DimCustomer, dbo.DimDate.
*/

-- 1. Executive KPIs
SELECT
    SUM(SalesAmount) AS TotalSales,
    SUM(Profit) AS TotalProfit,
    SUM(Profit) / NULLIF(SUM(SalesAmount), 0) AS ProfitMargin,
    COUNT(DISTINCT OrderID) AS CompletedOrders,
    SUM(SalesAmount) / NULLIF(COUNT(DISTINCT OrderID), 0) AS AverageOrderValue
FROM dbo.FactSales
WHERE Status = 'Completed';

-- 2. Monthly sales and profit trend
SELECT
    DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1) AS MonthStart,
    SUM(SalesAmount) AS TotalSales,
    SUM(Profit) AS TotalProfit,
    SUM(Profit) / NULLIF(SUM(SalesAmount), 0) AS ProfitMargin
FROM dbo.FactSales
WHERE Status = 'Completed'
GROUP BY DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1)
ORDER BY MonthStart;

-- 3. Regional ranking
SELECT
    r.Region,
    r.City,
    SUM(f.SalesAmount) AS TotalSales,
    SUM(f.Profit) AS TotalProfit,
    DENSE_RANK() OVER (ORDER BY SUM(f.SalesAmount) DESC) AS SalesRank
FROM dbo.FactSales AS f
JOIN dbo.DimRegion AS r
    ON r.RegionKey = f.RegionKey
WHERE f.Status = 'Completed'
GROUP BY r.Region, r.City
ORDER BY TotalSales DESC;

-- 4. Top 5 products
SELECT TOP (5)
    p.ProductName,
    p.Category,
    SUM(f.SalesAmount) AS TotalSales,
    SUM(f.Profit) AS TotalProfit,
    SUM(f.Quantity) AS UnitsSold
FROM dbo.FactSales AS f
JOIN dbo.DimProduct AS p
    ON p.ProductKey = f.ProductKey
WHERE f.Status = 'Completed'
GROUP BY p.ProductName, p.Category
ORDER BY TotalSales DESC;

-- 5. Salesperson performance
SELECT
    s.SalespersonName,
    r.Region,
    SUM(f.SalesAmount) AS TotalSales,
    SUM(f.Profit) AS TotalProfit,
    SUM(f.Profit) / NULLIF(SUM(f.SalesAmount), 0) AS ProfitMargin
FROM dbo.FactSales AS f
JOIN dbo.DimSalesperson AS s
    ON s.SalespersonKey = f.SalespersonKey
JOIN dbo.DimRegion AS r
    ON r.RegionKey = f.RegionKey
WHERE f.Status = 'Completed'
GROUP BY s.SalespersonName, r.Region
ORDER BY TotalSales DESC;

-- 6. Return rate
SELECT
    COUNT(DISTINCT CASE WHEN Status = 'Returned' THEN OrderID END) * 1.0
        / NULLIF(COUNT(DISTINCT CASE WHEN Status <> 'Cancelled' THEN OrderID END), 0) AS ReturnRate
FROM dbo.FactSales;

-- 7. Monthly regional target achievement
WITH MonthlySales AS (
    SELECT
        DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1) AS MonthStart,
        RegionKey,
        SUM(SalesAmount) AS TotalSales
    FROM dbo.FactSales
    WHERE Status = 'Completed'
    GROUP BY DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1), RegionKey
)
SELECT
    t.MonthStart,
    r.Region,
    ms.TotalSales,
    t.SalesTarget,
    ms.TotalSales - t.SalesTarget AS VarianceToTarget,
    ms.TotalSales / NULLIF(t.SalesTarget, 0) AS TargetAchievement
FROM dbo.FactTargets AS t
JOIN MonthlySales AS ms
    ON ms.MonthStart = t.MonthStart
    AND ms.RegionKey = t.RegionKey
JOIN dbo.DimRegion AS r
    ON r.RegionKey = t.RegionKey
ORDER BY t.MonthStart, r.Region;

